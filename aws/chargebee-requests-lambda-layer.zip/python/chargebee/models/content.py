from chargebee.result import Result


class Content(Result):
    pass
